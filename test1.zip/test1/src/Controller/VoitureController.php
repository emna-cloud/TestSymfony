<?php

namespace App\Controller;

use App\Entity\Voiture;
use App\Form\VoitureType; 
use App\Repository\VoitureRepository; // Assurez-vous d'inclure le repository
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class VoitureController extends AbstractController
{
    #[Route('/voiture', name: 'voiture_list')]
    public function list(EntityManagerInterface $entityManager): Response
    {
        // Récupérer toutes les voitures depuis la base de données
        $voitures = $entityManager->getRepository(Voiture::class)->findAll();

        return $this->render('voiture/list.html.twig', [
            'voitures' => $voitures,
        ]);
    }

    #[Route('/voiture/add', name: 'voiture_add')]
    public function add(Request $request, EntityManagerInterface $entityManager): Response
    {
        $voiture = new Voiture(); 
        $form = $this->createForm(VoitureType::class, $voiture);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($voiture);
            $entityManager->flush();

            return $this->redirectToRoute('voiture_list'); 
        }

        return $this->render('voiture/add.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    #[Route('/voiture/edit/{id}', name: 'voiture_edit')]
    public function edit(Request $request, VoitureRepository $voitureRepository, EntityManagerInterface $entityManager, int $id): Response
    {
        $voiture = $voitureRepository->find($id);
    
        $form = $this->createForm(VoitureType::class, $voiture);
        $form->handleRequest($request);
    
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();
            return $this->redirectToRoute('voiture_list');
        }
    
        return $this->render('voiture/edit.html.twig', [
            'form' => $form->createView(),
            'voiture' => $voiture,
        ]);
    }

    #[Route('/voiture/delete/{id}', name: 'voiture_delete')]
    public function delete(EntityManagerInterface $entityManager, int $id): Response
    {
        $voiture = $entityManager->getRepository(Voiture::class)->find($id);

        $entityManager->remove($voiture);
        $entityManager->flush();

        return $this->redirectToRoute('voiture_list');
    }
}
