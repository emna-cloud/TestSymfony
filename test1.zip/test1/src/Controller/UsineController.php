<?php

namespace App\Controller;

use App\Entity\Usine;
use App\Entity\Voiture; 

use App\Form\UsineType;
use App\Repository\UsineRepository; 
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class UsineController extends AbstractController
{
    #[Route('/usine', name: 'usine_list')]
    public function list(EntityManagerInterface $entityManager): Response
    {
        $usines = $entityManager->getRepository(Usine::class)->findAll();

        return $this->render('usine/list.html.twig', [
            'usines' => $usines,
        ]);
    }

    #[Route('/usine/add', name: 'usine_add')]
    public function add(Request $request, EntityManagerInterface $entityManager): Response
    {
        $usine = new Usine();
        $form = $this->createForm(UsineType::class, $usine);
        
        $form->handleRequest($request);
        
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($usine);
            $entityManager->flush();

            return $this->redirectToRoute('usine_list');
        }

        return $this->render('usine/add.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    #[Route('/usine/edit/{id}', name: 'usine_edit')]
    public function edit(Request $request, UsineRepository $usineRepository, EntityManagerInterface $entityManager, int $id): Response
    {
        $usine = $usineRepository->find($id);

        if ($usine === null) {
            return $this->redirectToRoute('usine_list', [
                'error' => 'Usine non trouvée.'
            ]);
        }

        $form = $this->createForm(UsineType::class, $usine);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('usine_list');
        }

        return $this->render('usine/edit.html.twig', [
            'form' => $form->createView(),
            'usine' => $usine,
        ]);
    }

    #[Route('/usine/delete/{id}', name: 'usine_delete')]
    public function delete(EntityManagerInterface $entityManager, int $id): Response
    {
        $usine = $entityManager->getRepository(Usine::class)->find($id);
    
        $voitures = $entityManager->getRepository(Voiture::class)->findBy(['usine' => $usine]);
        foreach ($voitures as $voiture) {
            $entityManager->remove($voiture);
        }
    
        $entityManager->remove($usine);
        $entityManager->flush();
    
        return $this->redirectToRoute('usine_list');
    }
    
}
