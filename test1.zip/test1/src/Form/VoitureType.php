<?php

namespace App\Form;

use App\Entity\Voiture;
use App\Entity\Usine;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class VoitureType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('nom')
            ->add('fabrication', null, [
                'widget' => 'single_text',
            ])
            ->add('prix')
            ->add('usine', EntityType::class, [
                'class' => Usine::class,
                'choice_label' => 'nom', // Affiche le nom de l'usine dans la liste déroulante
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Voiture::class,
        ]);
    }
}
